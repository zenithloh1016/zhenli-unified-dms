# ZHENLI Sequential Signing — native DMS login V1.5

This ZIP contains **one additive patch for the existing EdgeOne signing backend** and **one patch for the ZHENLI Unified DMS frontend**. Use the *same ZIP* in both GitHub repositories, applying **only the matching script** in each repo. There is no database migration. Existing Blob request records, PDF documents, signatures and audit logs are not touched.

## A. Sequential Signing repository (FIRST)

Back up your repository and confirm the correct branch. Upload the ZIP to the root of `ZHENLI-Sequential-Signing` and commit that ZIP. In its Codespaces terminal:

```sh
git pull --ff-only origin main
unzip -o ZHENLI_Native_Signing_Integration_V1_5.zip -d .
python3 ZHENLI_Native_Signing_Integration_V1_5/scripts/install_edgeone_v1_5.py
node --check 'cloud-functions/api/[[default]].js'
git diff -- 'cloud-functions/api/[[default]].js'
git add 'cloud-functions/api/[[default]].js'
git commit -m 'Enable native DMS signing session V1.5'
git push origin main
```

Configure EdgeOne **production** Environment Variable `DMS_ALLOWED_ORIGINS` to `https://zenithloh1016.github.io,http://localhost,https://localhost` (exact origin only; adjust if your Capacitor app uses a different origin). Redeploy **the existing signing project** using its existing `APP_SECRET`, `ADMIN_PASSWORD`, Blob store and SMTP settings. No new store or new signing website. Do not commit passwords, JWTs or protected EdgeOne preview-link tokens. The backend also retains the existing optional Supabase-verified `/api/dms/requests` access.

## B. DMS repository (SECOND)

Upload the same ZIP to `zhenli-unified-dms` and commit it. In that repo's Codespaces terminal:

```sh
git pull --ff-only origin main
unzip -o ZHENLI_Native_Signing_Integration_V1_5.zip -d .
python3 ZHENLI_Native_Signing_Integration_V1_5/scripts/install_dms_v1_5.py
node --check src/main.js
node --check src/signing-native.js
git diff --stat
git add src/main.js src/style.css src/signing-native.js
git commit -m 'Install native DMS Signing V1.5'
git push origin main
```

Rebuild the website and Android APK through GitHub Actions, and install the **new** APK. Open DMS > Signing. You should see **Native Signing V1.5**, enter the existing EdgeOne administrator password directly within DMS, then view/manage requests inside the DMS screen. The DMS calls EdgeOne backend `/api/dms/session` for login and `/api/dms/requests` for all admin actions; no EdgeOne page iframe is used. Signers' own signing links still open the signer webpage when the recipient signs.

## Safety and limitations

- Never use an expiring protected EdgeOne preview-link URL for the backend; use a stable service domain with API access protected by the admin session.
- This interface is not full single sign-on. A DMS account and a signing admin password are distinct.
- Bearer session is in browser JavaScript memory (not cookies/localStorage) and expires after 8 hours.
- Add EdgeOne platform rate-limiting / WAF protections to `/api/dms/session` before production use. The current signing app describes itself as a pilot with non-atomic Blob writes; review for use with legally significant documents.
- Public GitHub repo should contain **code only**—no company PDFs, credentials or client data.
- Check EdgeOne origin allowlist and API availability if CORS or 401 appears; log in again after a reload.
- `git add` only the listed source files, not backup files or extracted archives.
- The two installer scripts abort if current source differs materially from the supplied version; never force a blind overwrite.
