#!/usr/bin/env python3
# Safe additive patch for current DMS bearer bridge backend.
# No change to Blob data, original /api/login or signer routes.
from pathlib import Path
import shutil,sys
p=Path('cloud-functions/api/[[default]].js')
if not p.is_file():sys.exit('ERROR: Open the ZHENLI Sequential Signing repository root, not DMS.')
s=p.read_text(encoding='utf-8')
if 'ZHENLI_DMS_PASSWORD_SESSION_V1_5' in s:
    print('ALREADY INSTALLED: V1.5 password-session extension');sys.exit(0)
required=['const dmsRoute = req => /^\\/api\\/dms\\/requests(?:\\/|$)/.test(new URL(req.url).pathname);',
          'async function verifiedDmsAdmin(req,env){',
          'const dmsAdminRequest = dmsRoute(req);',
          'if (!await verifiedDmsAdmin(req,env)) return failure(\'DMS administrator authorization failed or DMS bridge is not configured\',401);',
          'parts.splice(1,1); // /api/dms/requests/... -> original trusted /api/requests/... handlers',
          'const dmsCors = origin => ({',
          'if(!dmsAdminRequest && !currentSession(req,env))return failure(\'Administrator login required\',401);']
for marker in required:
    if marker not in s:sys.exit(f'ERROR: Current EdgeOne backend differs at {marker[:65]!r}. No changes made.')
if 'function currentDmsPasswordSession(' in s:sys.exit('ERROR: Existing DMS password-session implementation detected. No changes made.')
oldroute=required[0]
newroute='const dmsRoute = req => /^\\/api\\/dms\\/(?:requests(?:\\/|$)|session$)/.test(new URL(req.url).pathname);'
assert s.count(oldroute)==1
s=s.replace(oldroute,newroute,1)
# Separate session tokens from Supabase JWT: origin-bound, HMAC-signed, eight-hour expiry.
anchor='const tokenFor = (r, s, env) =>'
assert s.count(anchor)==1
helper=r'''// ZHENLI_DMS_PASSWORD_SESSION_V1_5
// The DMS admin signs in *inside DMS*. Bearer stays in JS memory only.
// Existing Supabase-verified DMS requests and standalone EdgeOne login remain valid.
function issueDmsPasswordSession(origin,env) {
  const stamp=Math.floor(clock()/1000).toString();
  const nonce=id();
  const tag=mac(`dms-admin-v1:${origin}:${stamp}:${nonce}:${sha(password(env))}`,secret(env));
  return `d1.${stamp}.${nonce}.${tag}`;
}
function currentDmsPasswordSession(req,env) {
  const origin=dmsAllowedOrigin(req,env);
  if(!origin)return false;
  const bearer=/^Bearer d1\.(\d{10,12})\.([a-f0-9]{32})\.([a-f0-9]{64})$/.exec(req.headers.get('Authorization')||'');
  if(!bearer)return false;
  const age=Math.floor(clock()/1000)-Number(bearer[1]);
  if(!Number.isSafeInteger(age)||age<0||age>sessionTtl)return false;
  return eq(bearer[3],mac(`dms-admin-v1:${origin}:${bearer[1]}:${bearer[2]}:${sha(password(env))}`,secret(env)));
}

'''
s=s.replace(anchor,helper+anchor,1)
oldguard='''  if(dmsAdminRequest) {
    if (!await verifiedDmsAdmin(req,env)) return failure('DMS administrator authorization failed or DMS bridge is not configured',401);
    parts.splice(1,1); // /api/dms/requests/... -> original trusted /api/requests/... handlers
  }'''
newguard='''  if(dmsAdminRequest) {
    // Restrict all native DMS operations to allowlisted browser origins.
    if(!dmsAllowedOrigin(req,env))return failure('DMS origin not allowed',403);
    if(parts[2]==='session' && parts.length===3 && method==='POST') {
      if(req.headers.get('x-zh-request')!=='1')return failure('Invalid request header',403);
      const data=await req.json().catch(()=>({}));
      if(!eq(String(data.password||''),password(env)))return failure('Incorrect administrator password',401);
      return response({ok:true,token:issueDmsPasswordSession(dmsAllowedOrigin(req,env),env),expiresIn:sessionTtl,brand:companyBrand(env)});
    }
    if(method!=='GET' && method!=='HEAD' && req.headers.get('x-zh-request')!=='1')return failure('Invalid request header',403);
    if(!currentDmsPasswordSession(req,env) && !await verifiedDmsAdmin(req,env))
      return failure('DMS administrator authorization failed',401);
    parts.splice(1,1); // /api/dms/requests/... -> original trusted /api/requests/... handlers
  }'''
assert s.count(oldguard)==1
s=s.replace(oldguard,newguard,1)
backup=Path('.ZHENLI_EDGEONE_BEFORE_V1_5.js')
if not backup.exists():shutil.copy2(p,backup)
p.write_text(s,encoding='utf-8')
print('PASS: V1.5 native login added. Existing Supabase bridge and standalone EdgeOne login preserved.')
print('Backup created at',backup)
