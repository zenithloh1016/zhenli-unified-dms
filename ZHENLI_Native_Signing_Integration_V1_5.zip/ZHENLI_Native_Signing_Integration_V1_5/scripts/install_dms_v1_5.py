#!/usr/bin/env python3
"""Safe DMS native signing installer, supports original DMS and V1.4 patched DMS."""
from pathlib import Path
import subprocess,sys,shutil
root=Path.cwd()
main=root/'src/main.js';css=root/'src/style.css';target=root/'src/signing-native.js'
patchdir=Path(__file__).resolve().parent.parent
asset=patchdir/'src/signing-native.js'
if not main.is_file() or not (root/'package.json').is_file() or not css.is_file():
    sys.exit('ERROR: Run from ZHENLI Unified DMS repository root, not signing repo.')
s=main.read_text(encoding='utf-8')
if 'ZHENLI_DMS_NATIVE_SIGNING_V1_5' in s:
    print('ALREADY INSTALLED: DMS V1.5');sys.exit(0)
if 'createNativeSigning' in s and 'ZHENLI_DMS_NATIVE_SIGNING_V1_4' not in s:
    sys.exit('ERROR: Unknown native signing layout; no changes made.')
backup=root/'.ZHENLI_DMS_BEFORE_V1_5'
backup.mkdir(exist_ok=True)
for p in [main,css,target]:
    if p.is_file() and not (backup/p.name).exists():shutil.copy2(p,backup/p.name)
if 'ZHENLI_DMS_NATIVE_SIGNING_V1_4' not in s:
    run=subprocess.run([sys.executable,str(patchdir/'scripts/patch_dms_v1_4.py')],cwd=root)
    if run.returncode:sys.exit('ERROR: Original DMS patch failed; inspect changes before retrying.')
    s=main.read_text(encoding='utf-8')
if 'ZHENLI_DMS_NATIVE_SIGNING_V1_4' not in s:
    sys.exit('ERROR: Could not find V1.4 integration marker; no V1.5 upgrade performed.')
s=s.replace('ZHENLI_DMS_NATIVE_SIGNING_V1_4','ZHENLI_DMS_NATIVE_SIGNING_V1_5')
s=s.replace('Native Signing V1.4','Native Signing V1.5')
main.write_text(s,encoding='utf-8')
shutil.copy2(asset,target)
print('PASS: Native Signing V1.5 is installed in DMS (direct password login, no iframe).')
print('Backup of original DMS files:',backup)
