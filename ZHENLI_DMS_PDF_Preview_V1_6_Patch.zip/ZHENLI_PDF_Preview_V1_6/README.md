# ZHENLI DMS — Native Signing V1.6 PDF Signature Preview

Applies only to **zenithloh1016/zhenli-unified-dms**, based on the existing **Native Signing V1.5** source.

## What changes

- Displays the actual page of an uploaded draft-signing PDF inside the DMS using Mozilla PDF.js.
- Switches between PDFs and pages and selects the signer.
- Lets you tap an exact PDF position to add a signature box.
- Lets you drag an existing box to reposition it and drag its bottom-right handle to resize it.
- Syncs the existing Left %, Top %, Width %, Height % fields (top-left-origin percentages).
- The original **Save positions** button persists the boxes using the **unchanged** existing EdgeOne signing API.
- Displays boxes that were previously saved whenever draft request details are loaded.

**No backend, database, PDF storage, EdgeOne worker, signer-link, or authentication changes.** PDF bytes are fetched from the same authenticated DMS request endpoint as Download PDF, processed in browser memory, and never copied to local storage.

## Mobile-friendly installation via GitHub Codespaces

1. Open the GitHub repository `zenithloh1016/zhenli-unified-dms`, then its **Code → Codespaces** editor. Keep your current working repository and avoid touching the EdgeOne backend.
2. Open the Codespaces terminal at the repository root.
3. Make a separate branch *before editing*:

   ```sh
   git checkout -b feature/pdf-signature-preview
   ```

4. Upload `ZHENLI_DMS_PDF_Preview_V1_6_Patch.zip` into the repository's root folder using the Codespaces file explorer (right-click → Upload). Then run:

   ```sh
   unzip -o ZHENLI_DMS_PDF_Preview_V1_6_Patch.zip -d /tmp/zhenli-preview
   python3 /tmp/zhenli-preview/ZHENLI_PDF_Preview_V1_6/install_pdf_preview.py
   npm install --no-audit --no-fund
   npm run build
   ```

5. Test before deploying. If build succeeds, commit only the intended source and lockfile (if created):

   ```sh
   git status --short
   git add src/signature-preview.js src/signing-native.js src/main.js src/style.css package.json
   git add package-lock.json 2>/dev/null || true
   git commit -m "Add PDF page preview and draggable signature boxes to native signing"
   git push -u origin feature/pdf-signature-preview
   ```

6. Open a Pull Request on GitHub to merge the feature into `main` **after testing**. GitHub Actions deploys the website and builds the Android APK when `main` changes.

## Test checklist

- Sign into **DMS → Signing**, open an existing **draft** with PDFs, then open its Signature positions.
- Confirm PDF first page is visible and use the arrows for a multi-page PDF.
- Select PDF and signer. Tap **Tap PDF to add box**, then touch the intended signature area.
- Drag the dashed box. Resize using its bottom-right blue handle.
- Check that the coordinate inputs change. Click **Save positions**.
- Reload draft details. Ensure the same box reappears at the saved location.
- Check a separate signing request (and different PDF) and ensure boxes do not leak between requests.
- Open an existing signed request and ensure download, archive, and evidence actions are unaffected.
- Do not activate a production signing request merely to test the preview.

## Rollback

The installer saves the four original files in a timestamped folder under `.pdf-preview-backup/`. To restore the originals, copy them from the latest backup into their matching locations in the repository, delete `src/signature-preview.js`, then `npm install && npm run build`. The branch can also be discarded without affecting production.

**Important:** Do not commit `.pdf-preview-backup/` or the patch ZIP. Neither contains signer data, but they are unnecessary repository artifacts.

## Troubleshooting

- If the patch says an **anchor** is missing, stop. The DMS source has changed; do not overwrite with older versions.
- If the preview says it cannot fetch the PDF, verify the DMS session and the existing **Download PDF** button. The preview uses the same authenticated endpoint.
- If a page does not render, verify `npm install` finished and the browser supports PDF.js. Run `npm run build` and check browser console errors.
- If a signature box is not persisted, click **Save positions**. Dragging changes local coordinates only.
