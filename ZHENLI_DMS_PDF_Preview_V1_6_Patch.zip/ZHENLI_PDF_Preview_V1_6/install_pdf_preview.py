#!/usr/bin/env python3
"""Apply the NON-DESTRUCTIVE PDF preview patch to ZHENLI Unified DMS V1.5.

Run from the root of zenithloh1016/zhenli-unified-dms:
  python3 /path/to/ZHENLI_PDF_Preview_V1_6/install_pdf_preview.py

The script backs up each existing file to a local .pdf-preview-backup directory
and never changes stored signing records, signing API functions, or secrets.
"""
from pathlib import Path
import json
import shutil
import sys
from datetime import datetime, timezone

BASE = Path.cwd()
SELF = Path(__file__).resolve().parent
MARK = 'ZS_PDF_SIGNATURE_PREVIEW_V1_6'
PATHS = [
    'src/signing-native.js', 'src/main.js', 'src/style.css', 'package.json'
]


def replace_once(source, old, new, label):
    count = source.count(old)
    if count != 1:
        raise RuntimeError(f'Expected exactly one {label} anchor, found {count}. '
                           'The source may have changed. No files were updated.')
    return source.replace(old, new, 1)


def main():
    if not all((BASE / p).is_file() for p in PATHS):
        raise RuntimeError('Run this script from the repository root. '
                           'Expected src/signing-native.js and package.json.')
    src = {p: (BASE / p).read_text(encoding='utf-8') for p in PATHS}
    if MARK in src['src/signing-native.js']:
        print('PDF preview V1.6 is already installed. Nothing changed.')
        return
    signing = src['src/signing-native.js']
    signing = "import {createPdfSignaturePreview} from './signature-preview.js'; // " + MARK + "\n" + signing

    preview_setup = '''  // ZS_PDF_SIGNATURE_PREVIEW_V1_6: draft-only visual placement using existing API.
  const preview = createPdfSignaturePreview({
    fetchPdf: docId => api(`/requests/${detail.id}/docs/${encodeURIComponent(docId)}`, {binary:true}),
    getRows: () => captureRows(),
    setRow: (index, row) => {
      const element = document.querySelector(`.zs-placement-row[data-index="${index}"]`);
      if (!element) return;
      for (const field of ['x','y','width','height']) {
        const input = element.querySelector(`[name="${field}"]`);
        if (input) input.value = String(row[field]);
      }
    },
    addRow: row => {
      placementRows = captureRows();
      placementRows.push(row);
      update(); // Existing Save positions handler continues to own persistence.
    }
  });
'''
    signing = replace_once(signing, '  function main(){', preview_setup + '  function main(){', 'main() function')
    signing = replace_once(
        signing,
        '      <div id="zs-pdf-preview"></div>',
        '      ${pending?preview.html(r.docs,r.signers):\'\'}',
        'PDF preview placeholder'
    )
    signing = replace_once(
        signing,
        'async function open(rid){detail=await api(\'/requests/\'+encodeURIComponent(rid));view=\'detail\';',
        'async function open(rid){const oldId=detail?.id;detail=await api(\'/requests/\'+encodeURIComponent(rid));if(oldId!==detail.id)preview.reset();view=\'detail\';',
        'open(request) handler'
    )
    signing = replace_once(
        signing,
        "token='';requests=[];detail=null;view='login';feedback(msg);",
        "token='';requests=[];detail=null;preview.reset();view='login';feedback(msg);",
        'sign-out handler'
    )
    signing = replace_once(
        signing,
        '  return {render:()=>',
        "  return {mount:()=>{if(view==='detail'&&detail?.status==='draft')preview.mount(document.getElementById('zs-pdf-preview'));},\n"
        "    input:target=>{if(target?.closest?.('.zs-placement-row'))preview.drawBoxes(document.getElementById('zs-pdf-preview'));return false;},\n"
        '    render:()=>',
        'native signing public API'
    )
    signing = replace_once(signing, 'Native Signing V1.5</span>', 'Native Signing V1.6</span>', 'display version')
    src['src/signing-native.js'] = signing

    mainjs = src['src/main.js']
    mainjs = replace_once(
        mainjs,
        '  <input id="document-upload" type="file" multiple hidden />`;\n}',
        '  <input id="document-upload" type="file" multiple hidden />`;\n'
        "  if(state.tab==='signing') signingUI.mount();\n}",
        'render mount'
    )
    mainjs = replace_once(
        mainjs,
        "ROOT.addEventListener('input',e=>{if(e.target.id==='search')",
        "ROOT.addEventListener('input',e=>{signingUI.input(e.target);if(e.target.id==='search')",
        'coordinate input change listener'
    )
    src['src/main.js'] = mainjs
    src['src/style.css'] += '\n\n' + (SELF / 'signature-preview.css').read_text(encoding='utf-8')

    pkg = json.loads(src['package.json'])
    pkg.setdefault('dependencies', {})['pdfjs-dist'] = '^5.4.394'
    src['package.json'] = json.dumps(pkg, indent=2, ensure_ascii=False) + '\n'
    newfile = 'src/signature-preview.js'
    if (BASE / newfile).exists():
        raise RuntimeError(f'{newfile} already exists. No files were updated.')
    src[newfile] = (SELF / 'signature-preview.js').read_text(encoding='utf-8')

    # Validate all anchors BEFORE performing writes.
    backup_dir = BASE / '.pdf-preview-backup' / datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')
    backup_dir.mkdir(parents=True, exist_ok=True)
    for p in PATHS:
        backup_path = backup_dir / p
        backup_path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(BASE / p, backup_path)
    for p, content in src.items():
        dest = BASE / p
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_text(content, encoding='utf-8')
    print('PDF Signature Preview V1.6 source changes applied successfully.')
    print(f'Local source backups: {backup_dir.relative_to(BASE)}')
    print('Next: npm install --no-audit --no-fund && npm run build')
    print('Review/test first. Commit and push only after verification.')


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        print(f'NOT INSTALLED: {exc}', file=sys.stderr)
        sys.exit(1)
